function getBotResponse(input) {
  //rock paper scissors
  if (input == "1") {
    return "Selected option: Contract, Enter contract name";
  } else if (input == "2") {
    return "Selected option: JOBS, Enter job name";
  } else if (input == "3") {
    return "Selected option: User, Enter username";
  } else if (input == "4") {
    return "Selected option: Navigation, Enter destination";
  } else if (input == "5") {
    return "Selected option: Configuration, Enter config name";
  } else if (input == "*") {
    return botMenuItems();
  }

  // Simple responses
  if (input == "hello") {
    return "Hello there!";
  } else if (input == "goodbye") {
    return "Talk to you later!";
  } else {
    return "Try asking something else! or Return to the menu";
  }
}

function botMenuItems() {
  let menuStartMessage = "Get Instant Information";
  let menuItems = "\n1: Contract 2: Job 3: Configuration 4: User 5:Navigation";
  let menuEndMessage =
    "Select '*' to display the main menu Select '#' to exit the chat";
  let finalMsg =
    menuStartMessage + "<br>" + menuItems + "<br>" + menuEndMessage;
  return finalMsg;
}

function botMenu() {
  let menuStartMessage = "Get Instant Information";
  let menuItems = "\n1: Contract 2: Job 3: Configuration 4: User 5:Navigation";
  let menuEndMessage =
    "Select '*' to display the main menu Select '#' to exit the chat";
  document.getElementById("botMenuMessage").innerHTML =
    '<p class="botText"><span>' +
    menuStartMessage +
    "<br>" +
    menuItems +
    "<br>" +
    menuEndMessage;
  ("</span></p>");
}
