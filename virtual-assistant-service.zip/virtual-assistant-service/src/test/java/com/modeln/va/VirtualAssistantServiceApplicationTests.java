package com.modeln.va;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualAssistantServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
