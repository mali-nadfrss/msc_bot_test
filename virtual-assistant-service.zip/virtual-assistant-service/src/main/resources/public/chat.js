// Collapsible
var coll = document.getElementsByClassName("collapsible");

for (let i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");

    var content = this.nextElementSibling;

    if (content.style.maxHeight) {
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    }
  });
}

function getTime() {
  let today = new Date();
  hours = today.getHours();
  minutes = today.getMinutes();

  if (hours < 10) {
    hours = "0" + hours;
  }

  if (minutes < 10) {
    minutes = "0" + minutes;
  }

  let time = hours + ":" + minutes;
  return time;
}

// Gets the first message
function firstBotMessage() {
  let firstMessage = "Hi there, Welcome";
  document.getElementById("botStarterMessage").innerHTML =
    '<p class="botText"><span>' + firstMessage + "</span></p>";

  let time = getTime();

  $("#chat-timestamp").append(time);
  document.getElementById("userInput").scrollIntoView(false);
}

function botMenu() {
    let menuStartMessage = "Get Instant Information";
    let xhr= new XMLHttpRequest();
    var topicsUrl="http://localhost:8080/modeln/topics"
    xhr.open("GET",topicsUrl);
    xhr.send();
    xhr.onload= ()=>{
    if(xhr.status ==200){
        let dataResponse=(JSON.parse(xhr.response));
            (dataResponse.toString().split(',')).forEach(topicsFunc);
            document.getElementById("botMenuMessage").innerHTML =
            '<p class="botText"><span>' + menuStartMessage ;
            ("</span></p>");
        }
     }
}
/*
to create buttons with topics fetched from api call
*/
    function topicsFunc(item,index)
    {
        var btn=document.createElement('button');
        btn.setAttribute('class',item);
        btn.setAttribute('id',item);
        btn.setAttribute('style','background-color:DodgerBlue');
        btn.setAttribute('onclick','fetchQuestion(" '+item+' ")');
        btn.innerText=item;
        /*if(item == "Job" || item == "Users"  ){
        document.getElementById("topicButtons").appendChild(btn);
        }
        else{
        document.getElementById("questionButtons").appendChild(btn);
        }*/
        document.getElementById("topicButtons").appendChild(btn);
    }

/*
to create buttons with questions fetched from api call
*/
    function questionsFunc(item,index)
    {
        var btn=document.createElement('button');
        btn.setAttribute('class',item);
        btn.setAttribute('id',item);
        btn.setAttribute('style','background-color:DodgerBlue');
        btn.innerText=item;
        document.getElementById("questionButtons").appendChild(btn);
    }

/*
to fetch questions based on selected topic
*/
function fetchQuestion(item){
        let xhr= new XMLHttpRequest();
        let dataResponse="";
        var temp=item.toString().trim();
        var questhUrl="http://localhost:8080/modeln/questions/"+temp;
        console.log(questhUrl);
        xhr.open("GET",questhUrl);
        xhr.send();
        var questnArray=[];
        xhr.onload= ()=>
        {
            if(xhr.status ==200)
            {
                let dataResponse=(JSON.parse(xhr.response));
                for(var i in dataResponse)
                {
                    questnArray.push(dataResponse[i].displayName);

                }
                    questnArray.forEach(questionsFunc);

            }
        }
}

firstBotMessage();
botMenu();

// Retrieves the response
function getHardResponse(userText) {
  let botResponse = getBotResponse(userText);
  let botHtml = '<p class="botText"><span>' + botResponse + "</span></p>";
  $("#chatbox").append(botHtml);

  document.getElementById("chat-bar-bottom").scrollIntoView(true);
}

//Gets the text text from the input box and processes it
function getResponse() {
  let userText = $("#textInput").val();

  if (userText == "") {
    userText = "Invalid input!";
  }

  let userHtml = '<p class="userText"><span>' + userText + "</span></p>";

  $("#textInput").val("");
  $("#chatbox").append(userHtml);
  document.getElementById("chat-bar-bottom").scrollIntoView(true);

  setTimeout(() => {
    getHardResponse(userText);
  }, 1000);
}

// Handles sending text via button clicks
function buttonSendText(sampleText) {
  let userHtml = '<p class="userText"><span>' + sampleText + "</span></p>";

  $("#textInput").val("");
  $("#chatbox").append(userHtml);
  document.getElementById("chat-bar-bottom").scrollIntoView(true);

  //Uncomment this if you want the bot to respond to this buttonSendText event
  // setTimeout(() => {
  //     getHardResponse(sampleText);
  // }, 1000)
}

function sendButton() {
  getResponse();
}


function heartButton() {
  buttonSendText("Heart clicked!");
}

// Press enter to send a message
$("#textInput").keypress(function(e) {
  if (e.which == 13) {
    getResponse();
  }
});
