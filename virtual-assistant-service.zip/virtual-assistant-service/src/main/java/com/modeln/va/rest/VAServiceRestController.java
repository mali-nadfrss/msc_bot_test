package com.modeln.va.rest;

import com.modeln.va.config.VirtualAssistantConfig;
import com.modeln.va.persistence.VirtualAssistantService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@RestController
public class VAServiceRestController {
	
	@Autowired
	private VirtualAssistantConfig config;
	
	@Autowired
	private VirtualAssistantService vaService;
	
	@GetMapping(path = "/topics/**")
	public ResponseEntity alltopics( HttpServletRequest request){
		String requestPath = (String)request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
		requestPath = StringUtils.remove(requestPath, "/topics/");
		
		 List<String> nodes = Stream.of(requestPath.split("/"))
	                .filter(value ->
	                        value != null && value.length() > 0 ).collect(Collectors.toList());
		 
		return new ResponseEntity<>(
				config.getNodes(nodes), HttpStatus.OK); 
	}
	
	
	@GetMapping(path = "/questions/**")
	public ResponseEntity questions( HttpServletRequest request){
		String requestPath = (String)request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
		requestPath = StringUtils.remove(requestPath, "/questions/");
		
		 List<String> nodes = Stream.of(requestPath.split("/"))
	                .filter(value ->
	                        value != null && value.length() > 0 ).collect(Collectors.toList());
		 
		return new ResponseEntity<>(
				config.getQuestions(nodes), HttpStatus.OK); 
	}
	
	@GetMapping(path = "/response/**")
	public ResponseEntity responses( HttpServletRequest request , @RequestParam( name = "inputText") String inputText ){
		String requestPath = (String)request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
		requestPath = StringUtils.remove(requestPath, "/response/");
		
		 List<String> nodes = Stream.of(requestPath.split("/"))
	                .filter(value ->
	                        value != null && value.length() > 0 ).collect(Collectors.toList());
		 Object response = "";
		 if(nodes.size()>0) {
			 String questionId = nodes.get(nodes.size()-1);
			 String query = config.getQuery(nodes.subList(0, nodes.size()-1), questionId);
			 response = vaService.getResponse(query,inputText);
		 }
		 return new ResponseEntity<>(response, HttpStatus.OK); 
	}
	
	@GetMapping(path = "/config")
	public ResponseEntity<Map> config(){
		return new ResponseEntity<>(
				config.get(), HttpStatus.OK); 
	}
	
}
