package com.modeln.va.persistence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class VirtualAssistantService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	public Object getResponse(String sql, String inputText) {
		Object response = "";
	    Map sqlResult = jdbcTemplate.queryForMap(sql, inputText);
		if(!sqlResult.isEmpty()) {
			response = sqlResult.get("Response");
		}
	    return response;
	}

}
