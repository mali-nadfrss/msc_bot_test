package com.modeln.va.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Component
public class VirtualAssistantConfig {
	
	@Value("classpath:app-config/${virtual-assistant.config.location}")
	Resource resourceFile;
	
	private Map config;
	
	private final String QUESTIONS = "Questions";
	
	@PostConstruct
	public void load() {
		Yaml yaml = new Yaml();
		try(InputStream inputStream = resourceFile.getInputStream()){
			config =  yaml.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Map get(){
		return config;
	}
	
	public List<String> getNodes(List<String> nodeNames){
		List<String> childNodes = new ArrayList(config.keySet());
		if(nodeNames==null || nodeNames.size()==0) {
			childNodes = new ArrayList(config.keySet());
		}else {
			Map childNode = null;
			for(String node : nodeNames) {
				if(childNode==null) {
					childNode = (Map)config.get(node);
				}else {
					childNode = (Map)childNode.get(node);
				}
			}
			if(childNode!=null) {
				childNodes =  new ArrayList(childNode.keySet());
			}
		}
		childNodes.removeIf(node->node.equalsIgnoreCase(QUESTIONS));
		
		if(childNodes.isEmpty()) {
			childNodes.add("No sub topics available");
		}
		return childNodes;
	}

	public List getQuestions(List<String> nodeNames){
		List questions = Collections.EMPTY_LIST;
		if(nodeNames==null || nodeNames.size()==0) {
			questions = (List)config.get(QUESTIONS);
		}else {
			Map childNode = null;
			for(String node : nodeNames) {
				if(childNode==null) {
					childNode = (Map)config.get(node);
				}else {
					childNode = (Map)childNode.get(node);
				}
			}
			if(childNode!=null) {
				questions = (List)childNode.get(QUESTIONS) ;
			}
		}
		
		if(questions.isEmpty()) {
			questions.add("No questions available");
		}
		return questions;
	}
	
	
	
	public String getQuery(List<String> nodeNames, String questionId){
		List questions = getQuestions(nodeNames);
		String sqlQuery = null;
		if(nodeNames==null || nodeNames.size()==0) {
			questions = (List)config.get(QUESTIONS);
		}else {
			Map childNode = null;
			for(String node : nodeNames) {
				if(childNode==null) {
					childNode = (Map)config.get(node);
				}else {
					childNode = (Map)childNode.get(node);
				}
			}
			if(childNode!=null) {
				questions = (List)childNode.get(QUESTIONS) ;
			}
		}
		
		if(questions!=null) {
			for(Object question : questions ) {
				Map questionMap =  (Map)((Map)question).get("Q"+questionId);
				if(questionMap!=null && !questionMap.isEmpty()) {
					sqlQuery	= (String)questionMap.get("sqlQuery");
				}
			}
		}
		
		return sqlQuery;
	}
	
	
	
}
