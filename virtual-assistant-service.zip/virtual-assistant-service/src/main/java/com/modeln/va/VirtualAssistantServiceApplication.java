package com.modeln.va;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan( "com.modeln.va" )
public class VirtualAssistantServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualAssistantServiceApplication.class, args);
	}
	
	
}
